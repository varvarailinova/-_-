// Мобильное меню
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mainNav = document.getElementById('mainNav');
    
    if (mobileMenuBtn && mainNav) {
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('nav--active');
            
            // Анимация кнопки
            const lines = mobileMenuBtn.querySelectorAll('.mobile-menu-btn__line');
            lines.forEach(line => {
                line.style.transition = 'all 0.3s ease';
            });
            
            if (mainNav.classList.contains('nav--active')) {
                lines[0].style.transform = 'rotate(45deg) translateY(8px)';
                lines[1].style.opacity = '0';
                lines[2].style.transform = 'rotate(-45deg) translateY(-8px)';
            } else {
                lines[0].style.transform = 'none';
                lines[1].style.opacity = '1';
                lines[2].style.transform = 'none';
            }
        });
        
        // Закрытие меню при клике на ссылку
        const navLinks = mainNav.querySelectorAll('.nav__link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    mainNav.classList.remove('nav--active');
                    const lines = mobileMenuBtn.querySelectorAll('.mobile-menu-btn__line');
                    lines[0].style.transform = 'none';
                    lines[1].style.opacity = '1';
                    lines[2].style.transform = 'none';
                }
            });
        });
    }
});
